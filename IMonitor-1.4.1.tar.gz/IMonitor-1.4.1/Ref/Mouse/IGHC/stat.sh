perl /ifs1/ST_MED/USER/zhangwei/bin/chang_fa_1_line.pl IGH_C_raw_F_ORF_allP.fa |perl get_CH1_fa.pl - >Mouse_IGH_CH1.fa
