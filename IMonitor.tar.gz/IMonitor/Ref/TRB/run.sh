sh ../bin/run.sh TRBV_ref_from_IMGT_sort_201209.txt TRBJ_ref_from_IMGT_sort_201209.new.txt V211J25 t.txt TRB . 1 TRBD_ref_from_IMGT_sort_201209.txt
