perl ../IMonitor.pl -i data/XHS.merged.fa.gz  -o . -n XHS -T TRB -k 100 -r /ifs1/ST_MED/USER/zhangwei/Immunity/Bioinf/pipeline/IMonitor_for_submit/Ref/TRB -d -m
