#!/usr/bin/perl -w
use strict;

die "perl $0 <dir> <sample> <fa-flag> <sequence-error-flag>\n" unless(@ARGV==4);

print "#Title\tSeq_num\tRate_of_input(%)\tRate_of_rawdata(%)\n";

my $flag = $ARGV[2];
my $error_f = $ARGV[3];
my $raw = 0;
if($flag)
{
	open I, "$ARGV[0]/${ARGV[1]}_raw_data_filter_1.txt" or die;
	while(<I>)
	{
	chomp;
	my @line = split;
	if(/All_read_number\(PE=1\):/){
		$line[0] =~s/:$//;
		print "Raw_seq_number(PE=1)\t$line[1]\t-\t-\n";
		$raw = $line[1];
	}
	elsif(/retained_read_num:/){
		my $r_i = sprintf("%0.2f",$line[2]);
		print "Clean_data\t$line[1]\t$r_i\t$r_i\n";
	}
	}
	close I;

	open I, "$ARGV[0]/${ARGV[1]}_merge_filter_1.txt" or die;
	while(<I>)
	{
	chomp;
	my @line = split;
	if(/Merged_seq_raw:/){
		my $r_i = sprintf("%0.2f",$line[2]);
		my $r_r = sprintf("%0.2f",$line[1]/$raw*100);
		print "PE_read_merged\t$line[1]\t$r_i\t",$r_r,"\n";
	}
	if(/Merged_seq_with_high_quality:/){
		my $r_i = sprintf("%0.2f",$line[2]);
		my $r_r = sprintf("%0.2f",$line[1]/$raw*100);
		print "Merged_with_highquality\t$line[1]\t$r_i\t$r_r\n";
	}
	}
	close I;

}


my $before_eff = 0;
open I, "$ARGV[0]/${ARGV[1]}_VDJ.alignment.stat_2.txt" or die;
while(<I>)
{
	chomp;
	my @line = split;

	if($flag==0){
		if(/^sequence_num:/){
			print "Raw_seq_number\t$line[1]\t-\t-\n";
			$raw = $line[1];
		}
	}

	my $r_i = sprintf("%0.2f",$line[2]) if($.>1);
	my $r_r = sprintf("%0.2f",$line[1]/$raw*100);
	if(/^V_alignment_rate:/){
		print "V_alignment\t$line[1]\t$r_i\t$r_r\n";
	}
	elsif(/^D_alignment_rate:/){
		print "D_alignment\t$line[1]\t$r_i\t$r_r\n";
        }
	elsif(/^J_alignment_rate:/){
		print "J_alignment\t$line[1]\t$r_i\t$r_r\n";
	}
	elsif(/^VJ_alignment_rate:/){
		print "VJ_alignment\t$line[1]\t$r_i\t$r_r\n";
		$before_eff = $line[1];
	}


}
close I;
#if(-e "$ARGV[0]/${ARGV[1]}_pcr_seq_error_cor_3.txt" and -s "$ARGV[0]/${ARGV[1]}_pcr_seq_error_cor_3.txt")
if($error_f)
{
	if(-e "$ARGV[0]/${ARGV[1]}_pcr_seq_error_cor_3.txt" and -s "$ARGV[0]/${ARGV[1]}_pcr_seq_error_cor_3.txt")
	{
	open I, "$ARGV[0]/${ARGV[1]}_pcr_seq_error_cor_3.txt" or die;
	my $input;
	while(<I>)
	{
		chomp;
		my @line = split;
		if(/^all_raw_seq:/){
			$input = $line[1];
		}
		if(/new_core_sequence:/){
			my $r_i = sprintf("%0.2f",$line[1]/$input*100);
			my $r_r = sprintf("%0.2f",$line[1]/$raw*100);
			print "PCR_Sequencing_correct\t$line[1]\t$r_i\t$r_r\n";
			$before_eff = $line[1];
		}

	}
	close I;
	}else{
		print "Error: ${ARGV[1]}_pcr_seq_error_cor_3.txt is not existed!\n";
	}
}

open I , "$ARGV[0]/${ARGV[1]}_structure.stat_3.txt" or die;
my $input = $before_eff ;
while(<I>)
{
	chomp;
	my @line = split;
	if(/Retained_seq:/){
		my $r_i = sprintf("%0.2f",$line[1]/$input*100);
		my $r_r = sprintf("%0.2f",$line[1]/$raw*100);
		print "Effective_data\t$line[1]\t$r_i\t$r_r\n";
	}
}
close I;

print "\n\n";
print "----------Note:--------------\n";
print "Clean_data: filter the Adapter pollution,low quality sequence\n";
print "Effective_data: filter the sequence: 1. without V or J gene; 2. V and J strand conflict; 3. CDR3 less than 0bp; 4. sequence abundance filter; 5. optionally, primer filter.\n";


