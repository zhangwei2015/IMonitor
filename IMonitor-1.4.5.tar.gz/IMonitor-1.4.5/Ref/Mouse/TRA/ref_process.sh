date
perl /hwfssz1/ST_PRECISION/USER/xianghaitao/bin/ref_process/IMGT_REF_process.pl   -refV ./TRA.V_ref_from_IMGT_20181218.fa   -refJ ./TRA.J_ref_from_IMGT_20181218.fa   -blast_version 1

date
