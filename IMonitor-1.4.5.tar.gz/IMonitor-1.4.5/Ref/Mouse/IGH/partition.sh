perl ref_zoning.pl -v IGHV_inframe_raw_oneline.fa -j IGHJ_inframe_raw.fa -ov IGHV_inframe_partition.txt -oj IGHJ_inframe_partition.txt
