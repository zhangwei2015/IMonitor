sh ../../bin/run.sh IGHV.MacVJ.ref.fa IGHJ.MacVJ.ref.fa V297J23 t.txt IGH /data/Public_tools/Pipeline/pipeline_hwfssz1/IMonitor/IMonitor-1.4.1/Ref/Monkey/IGH 1 IGHD_from_IMGT_20200801_raw.fa
