perl Sort_V.pl  >IGHV.MacVJ.ref.fa
