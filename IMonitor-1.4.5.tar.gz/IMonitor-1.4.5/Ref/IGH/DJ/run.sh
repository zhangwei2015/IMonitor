sh ../../bin/run.sh IGH_D_ref.fa ../IGHJ_ref_from_IMGTF+ORF+in-frameP_sort_202102.txt V150J32 t.txt IGH /data/Public_tools/Pipeline/pipeline_hwfssz1/IMonitor/IMonitor-1.4.3/Ref/IGH/DJ 1
