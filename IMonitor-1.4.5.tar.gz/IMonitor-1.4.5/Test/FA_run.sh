perl ../IMonitor.pl -i data/XHS.merged.fa.gz  -o . -n XHS -T TRB -k 100 -r ../Ref/TRB -d -m -c -Rs /opt/blc/genome/biosoft/R/bin/Rscript
