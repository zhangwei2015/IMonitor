perl ../IMonitor.pl -iq Zebra_test.fq.gz -o /ifs1/ST_IM/USER/zhaoyi2/bin/IMonitor-1.3.0/Test -n Zebra -t TRB --seqType 1 -v 33 -d -ec -mul 1
