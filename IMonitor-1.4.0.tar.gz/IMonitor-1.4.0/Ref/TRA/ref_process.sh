date
perl /hwfssz1/ST_PRECISION/USER/xianghaitao/bin/ref_process/IMGT_REF_process.pl   -refV ./TRA.V_ref_from_IMGT_20180423.fa   -refJ ./TRA.J_ref_from_IMGT_20180423.fa   -blast_version 1

date
